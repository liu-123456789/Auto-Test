package com.example.uexchtext;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UexchTestApplicationTests {

    @Test
    void contextLoads() {
    }

}
