package com.example.uexchtext.model;


import lombok.Data;

@Data
public class CusTomer {
    private Integer id;
    private String email;
    private String invite_code;
    private String password;
}
