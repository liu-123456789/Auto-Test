package com.example.uexchtext.model;


import lombok.Data;

@Data
public class RegisterCaser {
  private int id;
  private String uri;
  private String path;
  private String account;
  private String passwd;
  private String code;
  private String imageId;
  private String imageCode;
  private String inviteCode;
  private String channelId;
}
