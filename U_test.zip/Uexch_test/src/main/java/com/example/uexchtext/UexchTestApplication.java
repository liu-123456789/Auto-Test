package com.example.uexchtext;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UexchTestApplication {

    public static void main(String[] args) {
        SpringApplication.run(UexchTestApplication.class, args);
    }

}
