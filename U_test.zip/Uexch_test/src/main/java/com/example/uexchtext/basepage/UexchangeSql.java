package com.example.uexchtext.basepage;

import com.example.uexchtext.model.CusTomer;
import com.example.uexchtext.utils.MysqlDatabaseUtils;
import org.apache.ibatis.session.SqlSession;

import java.io.IOException;


//查出创建用户
public class UexchangeSql {
    public String regitersql(String email) throws IOException {
        SqlSession sqlSession = MysqlDatabaseUtils.Uexsession();
        CusTomer cusTomer = sqlSession.selectOne("registeronerem", email);
        String email1 = null;
        try {
//            System.out.println(cusTomer.toString());
            email1 = cusTomer.getEmail();
        } catch (NullPointerException e) {
            return "this null";
        }
            return email1;


    }
}
