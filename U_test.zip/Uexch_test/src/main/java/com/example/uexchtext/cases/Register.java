package com.example.uexchtext.cases;

import com.example.uexchtext.casesmodel.CaseModel;
import com.example.uexchtext.basepage.UexchangeSql;
import com.example.uexchtext.registerhttpclient.RegisterHttpClient;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.io.IOException;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.ResourceBundle;

public class Register {

    private static ResourceBundle bundle=ResourceBundle.getBundle("application", Locale.CHINA);
    @Test
    public void CasesRgister(String registerone,Integer id) throws Exception {

        UexchangeSql uexchangeSql=new UexchangeSql();
        Map<String,String> map=new HashMap<>();
        CaseModel caseModel=new CaseModel();
        map=caseModel.regiter(registerone,id);
        String email=map.get("email");
        String requests=map.get("requests");
        RegisterHttpClient registerHttpClient=new RegisterHttpClient();
        System.out.println(requests);

        RegisterHttpClient registerHttpClient1=new RegisterHttpClient();
        JSONObject jsonObject=registerHttpClient1.registerhttpclient(requests);

        String str2=jsonObject.getString("message");
//        System.out.println(str2);
        String message=bundle.getString("test.message");
        Assert.assertEquals(str2,message);

        String stri=uexchangeSql.regitersql(email);
       // System.out.println(stri);
        if (stri.equals("this null")){
//            System.out.println("没有生成");
            throw new Exception("没有生成账户");
        }



    }


}
