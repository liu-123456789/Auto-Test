package com.example.uexchtext.casestest;

import com.example.uexchtext.cases.Register;
import org.testng.annotations.Test;

public class RegisterTest {

    @Test
    public void registers() throws Exception {
        Register register=new Register();
        register.CasesRgister("registerone",1);
    }
}
