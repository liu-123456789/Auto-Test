package com.example.uexchtext.casesmodel;

import com.example.uexchtext.model.RegisterCaser;
import com.example.uexchtext.utils.MysqlDatabaseUtils;
import org.apache.ibatis.session.SqlSession;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class CaseModel {
    private String requests,accout,passwd,code,imageId,imageCode,inviteCode,channelId;

    public RegisterCaser sqlconfig(String name,Integer id) throws IOException {
        SqlSession sqlSession= MysqlDatabaseUtils.sqlSession();
        RegisterCaser registerCaser=sqlSession.selectOne(name,id);
        return registerCaser;
    }

    public Map regiter(String registerone,Integer id) throws IOException {
        CaseModel caseModel=new CaseModel();
        RegisterCaser registerCaser= caseModel.sqlconfig(registerone,id);
        requests= registerCaser.getUri()+"://"+registerCaser.getPath();
        accout=registerCaser.getAccount();
        passwd=registerCaser.getPasswd();
        code=registerCaser.getCode();
        imageId=registerCaser.getImageId();
        imageCode=registerCaser.getImageCode();
        inviteCode=registerCaser.getInviteCode();
        channelId=registerCaser.getChannelId();
        String uri="%s?account=%s&passwd=%s&rePasswd=%s&code=%s&imageId=%s&imageCode=%s&channelId=%s";
        String w=String.format(uri,this.requests,this.accout,this.passwd,this.passwd,this.code,this.imageId,
                this.imageCode,this.channelId);
        Map<String ,String> map=new HashMap<>();
        map.put("requests",w);
        map.put("email",this.accout);
        return map;
    }

}
