package com.example.uexchtext.registerhttpclient;

import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.json.JSONObject;

import java.io.IOException;

public class RegisterHttpClient {
    public JSONObject registerhttpclient(String requests) throws IOException {
        DefaultHttpClient defaultHttpClient=new DefaultHttpClient();
        HttpPost post=new HttpPost(requests);
        JSONObject jsonObject=new JSONObject();
        post.addHeader("Accept","application/json");
        post.addHeader("Content-Type","application/json");
        StringEntity entity=new StringEntity(jsonObject.toString(),"UTF-8");
        post.setEntity(entity);
        String result;
        HttpResponse response=defaultHttpClient.execute(post);
        result= EntityUtils.toString(response.getEntity(),"UTF-8");
        //System.out.println(result);
        JSONObject jsonObject1=new JSONObject(result);
        return jsonObject1;
    }
}
